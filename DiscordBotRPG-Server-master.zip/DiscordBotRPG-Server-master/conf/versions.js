module.exports = {
    server: "1.13.6",
    website: null,
}