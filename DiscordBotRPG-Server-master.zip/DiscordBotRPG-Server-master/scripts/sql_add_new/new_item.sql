INSERT INTO itemsbase VALUES 
(ID, IDType, IDRarity, Image(url), IDSubtype);

INSERT INTO localizationitems VALUES
(ID, "en", Name, Description),